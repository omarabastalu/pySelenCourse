from selenium.webdriver.common.by import By


class LoginPageLocators(object):
    click_register = dict(type=By.XPATH, value="//a[@class='theme-btn register-btn']")
    type_name = dict(type=By.XPATH, value="//input[@id='name']")
    type_email = dict(type=By.XPATH, value="//input[@id='email']")
    checkbox = dict(type=By.XPATH, value="//input[@id='allowMarketingEmails']")
    send_code_btn = dict(type=By.XPATH, value="//button[@id='otp-login-btn']")
