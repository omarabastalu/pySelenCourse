from selenium.webdriver.common.by import By


class PracticePageLocators(object):
    radio_button = dict(type=By.XPATH, value="//input[@value='radio3' and @type='radio']")
    type_country = dict(type=By.XPATH, value="//input[@id='autocomplete']")
    click_dropdown = dict(type=By.XPATH, value="//select[@id='dropdown-class-example']")
    select_option2 = dict(type=By.XPATH, value="//option[@value='option2' and contains(text(),'Option2')]")
    click_home_btn = dict(type=By.XPATH, value="//button[@class='btn btn-primary' and contains(text(),'Home')]")
