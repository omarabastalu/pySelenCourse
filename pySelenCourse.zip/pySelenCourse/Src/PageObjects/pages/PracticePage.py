from Src.PageObjects.pages.PracticePageLocators import PracticePageLocators


class PracticePage(object):
    def __init__(self, driver):
        self.driver = driver

        self.radio_button = driver.find_element(PracticePageLocators.radio_button.get("type"),
                                                PracticePageLocators.radio_button.get("value"))

        self.type_country = driver.find_element(PracticePageLocators.type_country.get("type"),
                                                PracticePageLocators.type_country.get("value"))

        self.click_dropdown = driver.find_element(PracticePageLocators.click_dropdown.get("type"),
                                                  PracticePageLocators.click_dropdown.get("value"))

        self.select_option2 = driver.find_element(PracticePageLocators.select_option2.get("type"),
                                                  PracticePageLocators.select_option2.get("value"))

        self.click_home_btn = driver.find_element(PracticePageLocators.click_home_btn.get("type"),
                                                  PracticePageLocators.click_home_btn.get("value"))

    def get_radio_button(self):
        return self.radio_button

    def get_type_country(self):
        return self.type_country

    def get_click_dropdown(self):
        return self.click_dropdown

    def get_select_option2(self):
        return self.select_option2

    def get_click_home_btn(self):
        return self.click_home_btn
