from Src.PageObjects.pages.LoginPageLocators import LoginPageLocators


class LoginPage(object):
    def __init__(self, driver):
        self.driver = driver

        self.click_register = driver.find_element(LoginPageLocators.click_register.get("type"),
                                                  LoginPageLocators.click_register.get("value"))

        self.type_name = driver.find_element(LoginPageLocators.type_name.get("type"),
                                             LoginPageLocators.type_name.get("value"))

        self.type_email = driver.find_element(LoginPageLocators.type_email.get("type"),
                                              LoginPageLocators.type_email.get("value"))

        self.checkbox = driver.find_element(LoginPageLocators.checkbox.get("type"),
                                            LoginPageLocators.checkbox.get("value"))

        self.send_code_btn = driver.find_element(LoginPageLocators.send_code_btn.get("type"),
                                                 LoginPageLocators.send_code_btn.get("value"))

    def get_click_register(self):
        return self.click_register

    def get_type_name(self):
        return self.type_name

    def get_type_email(self):
        return self.type_email

    def get_checkbox(self):
        return self.checkbox

    def get_send_code_btn(self):
        return self.send_code_btn
