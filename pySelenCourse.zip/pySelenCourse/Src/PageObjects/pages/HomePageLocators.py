from selenium.webdriver.common.by import By


class HomePageLocators(object):
    click_courses = dict(type=By.XPATH, value="(//a[contains(text(),'Courses')])[1]")
    find_a_product_type = dict(type=By.XPATH, value="//input[@id='search-courses']")
    click_search = dict(type=By.XPATH, value="//button[@id='search-course-button']")
