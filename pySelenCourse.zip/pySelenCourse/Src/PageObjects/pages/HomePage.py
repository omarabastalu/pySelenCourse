from Src.PageObjects.pages.HomePageLocators import HomePageLocators


class HomePage(object):
    def __init__(self, driver):
        self.driver = driver

        self.click_courses = driver.find_element(HomePageLocators.click_courses.get("type"),
                                                 HomePageLocators.click_courses.get("value"))

        self.find_a_product_type = driver.find_element(HomePageLocators.find_a_product_type.get("type"),
                                                       HomePageLocators.find_a_product_type.get("value"))

        self.click_search = driver.find_element(HomePageLocators.click_search.get("type"),
                                                HomePageLocators.click_search.get("value"))

    def get_click_courses(self):
        return self.click_courses

    def get_find_a_product_type(self):
        return self.find_a_product_type

    def get_click_search(self):
        return self.click_search
