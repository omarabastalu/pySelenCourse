from unittest import TestLoader, TestSuite, TextTestRunner
from Test.Scripts.TestCase1 import TestCase1


if __name__ == "__main__":
    test_loader = TestLoader()

    test_suite = TestSuite((test_loader.loadTestsFromTestCase(TestCase1)))
    test_runner = TextTestRunner(verbosity=2)
    test_runner.run(test_suite)
