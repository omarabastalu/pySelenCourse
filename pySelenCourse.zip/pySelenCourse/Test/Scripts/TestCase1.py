import time
import unittest
from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from Src.PageObjects.pages.PracticePage import PracticePage
from Src.PageObjects.pages.LoginPage import LoginPage
from Src.PageObjects.pages.HomePage import HomePage
from time import sleep
from selenium.webdriver.common.keys import Keys
from Src.utils import WebDriverUtil


class TestCase1(unittest.TestCase):
    def test_framework(self):
        options = webdriver.ChromeOptions()
        service = Service("C://chromedriver-win64//chromedriver.exe")
        driver = webdriver.Chrome(service=service, options=options)
        driver.implicitly_wait(15)
        driver.get("https://rahulshettyacademy.com/AutomationPractice/")

        practice_page = PracticePage(driver)
        radio_button = practice_page.get_radio_button().click()
        type_country = practice_page.get_type_country().send_keys("Mexico")
        click_dropdown = practice_page.get_click_dropdown().click()
        select_option2 = practice_page.get_select_option2().click()
        time.sleep(5)
        click_home_btn = practice_page.get_click_home_btn().click()
        time.sleep(5)

        driver.get("https://rahulshettyacademy.com/")
        home_page = HomePage(driver)
        click_courses = home_page.get_click_courses().click()
        find_a_product_type = home_page.get_find_a_product_type().send_keys("Selenium")
        click_search = home_page.get_click_search().click()

        login_page = LoginPage(driver)
        click_register = login_page.get_click_register().click()
        time.sleep(5)
        type_name = login_page.get_type_name().send_keys("Omar Abasta")
        type_email = login_page.get_type_email().send_keys("@outlook.com")
        checkbox = login_page.get_checkbox().click()
        send_code_btn = login_page.get_send_code_btn().click

        time.sleep(5)
        driver.quit()
        #driver.close()


if __name__ == '__main__':
    unittest.main()
